const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
const fs = require('fs');
require('dotenv').config();
const USE_LOCAL_DB = (process.env.USE_LOCAL_DB || 'true') !== 'false';
let Student;
let Recruiter;
let Application;
let ContactMessage;
let newApplication;

if (USE_LOCAL_DB) {
  const local = require('./localdb/collections');
  Student = local.Student;
  Recruiter = local.Recruiter;
  Application = local.Application;
  ContactMessage = local.ContactMessage;
  newApplication = local.newApplication;
} else {
  const User = require('./models/User');
  Student = require('./models/Student');
  Recruiter = require('./models/Recruiter');
  Application = require('./models/Application');
  ContactMessage = require('./models/ContactMessage');
}

const app = express();
const PORT = process.env.PORT || 5050;
const HOST = process.env.HOST || '127.0.0.1';
const JWT_SECRET = process.env.JWT_SECRET || 'change_me_in_env';
const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI || 'mongodb://localhost:27017/placementhub';

function logError(scope, err) {
  try {
    const line = `[${new Date().toISOString()}] ${scope}: ${err && err.stack ? err.stack : (err && err.message ? err.message : String(err))}\n`;
    const logPath = path.join(__dirname, 'data', 'server.log');
    fs.mkdirSync(path.dirname(logPath), { recursive: true });
    fs.appendFileSync(logPath, line, 'utf8');
  } catch {}
}

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Do not set a global Content-Type header; let each route respond appropriately

// Health route
app.get('/api/health', (req, res) => {
  res.json({ ok: true, env: process.env.NODE_ENV || 'development' });
});

// Connect to MongoDB only if not using local JSON store
if (!USE_LOCAL_DB) {
  mongoose
    .connect(MONGODB_URI)
    .then(() => console.log(`MongoDB connected`))
    .catch((err) => {
      console.error('MongoDB connection error:', err.message);
      process.exit(1);
    });
} else {
  console.log('Using local JSON datastore (no MongoDB connection).');
}

// Signup endpoint
app.post('/api/signup', async (req, res) => {
  try {
    const { email, password, fullName, userType, college, course, graduationYear, companyName, designation } = req.body;
    if (!email || !password || !fullName || !userType) {
      return res.status(400).json({ message: 'Missing required fields.' });
    }
    if (!/^(?!\d)[\w.+-]+@([\w-]+\.)+[\w-]{2,}$/i.test(email)) {
      return res.status(400).json({ message: 'Invalid email: must not start with a digit and must contain @' });
    }
    if (!['student', 'recruiter'].includes(userType)) {
      return res.status(400).json({ message: 'Invalid userType. Must be student or recruiter.' });
    }
    const existingStudent = userType === 'student' ? await Student.findOne({ email }) : null;
    const existingRecruiter = userType === 'recruiter' ? await Recruiter.findOne({ email }) : null;
    const existingUser = existingStudent || existingRecruiter;
    if (existingUser) {
      return res.status(409).json({ message: 'User already exists.' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    if (userType === 'student') {
      await Student.create({
        email,
        password: hashedPassword,
        fullName,
        userType: 'student',
        college,
        course,
        graduationYear,
      });
    } else if (userType === 'recruiter') {
      if (!companyName) return res.status(400).json({ message: 'Company name is required for recruiters' });
      await Recruiter.create({
        email,
        password: hashedPassword,
        fullName,
        userType: 'recruiter',
        companyName,
        designation,
      });
    }

    const sanitized = { email, fullName, userType };
    res.status(201).json({ message: 'User registered successfully.', user: sanitized });
  } catch (err) {
    console.error('Signup error:', err);
    logError('signup', err);
    if (err && err.code === 11000) {
      return res.status(409).json({ message: 'User already exists (duplicate key).' });
    }
    if (err && err.name === 'ValidationError') {
      const firstKey = Object.keys(err.errors || {})[0];
      const firstMsg = firstKey ? (err.errors[firstKey]?.message || 'Validation error') : 'Validation error';
      return res.status(400).json({ message: firstMsg });
    }
    const expose = process.env.NODE_ENV !== 'production' && err && err.message ? err.message : 'Internal server error.';
    res.status(500).json({ message: expose });
  }
});

// Login endpoint
app.post('/api/login', async (req, res) => {
  try {
    const { email, password, userType } = req.body;
    if (!/^(?!\d)[\w.+-]+@([\w-]+\.)+[\w-]{2,}$/i.test(email)) {
      return res.status(400).json({ message: 'Invalid email: must not start with a digit and must contain @' });
    }
    let userDoc = null;
    if (userType === 'student') {
      userDoc = await Student.findOne({ email });
    } else if (userType === 'recruiter') {
      userDoc = await Recruiter.findOne({ email });
    }
    if (!userDoc) {
      return res.status(401).json({ message: 'Invalid credentials.' });
    }
    const isMatch = await bcrypt.compare(password, userDoc.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials.' });
    }
    const token = jwt.sign({ email: userDoc.email, userType }, JWT_SECRET, { expiresIn: '1h' });
    const sanitized = { email: userDoc.email, fullName: userDoc.fullName, userType };
    res.json({ token, user: sanitized });
  } catch (err) {
    console.error('Login error:', err);
    logError('login', err);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Profile routes (basic auth by email+userType from client)
app.get('/api/profile', async (req, res) => {
  try {
    const { email, userType } = req.query;
    if (!email || !userType) return res.status(400).json({ message: 'Missing email or userType' });
    let user = null;
    if (userType === 'student') {
      user = await Student.findOne({ email });
    } else if (userType === 'recruiter') {
      user = await Recruiter.findOne({ email });
    }
    if (!user) return res.status(404).json({ message: 'User not found' });
    delete user.password;
    res.json({ user });
  } catch (e) {
    console.error('Get profile error:', e);
    logError('get_profile', e);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

app.put('/api/profile', async (req, res) => {
  try {
    const { email, userType } = req.body;
    if (!email || !userType) return res.status(400).json({ message: 'Missing email or userType' });

    const updatable = {
      // basic
      fullName: req.body.fullName,
      username: req.body.username,
      // personal
      dob: req.body.dob,
      gender: req.body.gender,
      phone: req.body.phone,
      addressLine1: req.body.addressLine1,
      addressLine2: req.body.addressLine2,
      city: req.body.city,
      state: req.body.state,
      pincode: req.body.pincode,
      // academic
      college: req.body.college,
      course: req.body.course,
      department: req.body.department,
      enrollmentNumber: req.body.enrollmentNumber,
      semester: req.body.semester,
      graduationYear: req.body.graduationYear,
      cgpa: req.body.cgpa,
      tenthMarks: req.body.tenthMarks,
      twelfthMarks: req.body.twelfthMarks,
      backlogsCount: req.body.backlogsCount,
      // recruiter
      companyName: req.body.companyName,
      designation: req.body.designation,
      // skills & certs
      technicalSkills: req.body.technicalSkills,
      softSkills: req.body.softSkills,
      certifications: req.body.certifications,
      // internship / projects
      internshipTitle: req.body.internshipTitle,
      internshipCompany: req.body.internshipCompany,
      internshipDuration: req.body.internshipDuration,
      internshipDescription: req.body.internshipDescription,
      projectDetails: req.body.projectDetails,
      // placement prefs
      preferredRole: req.body.preferredRole,
      preferredLocation: req.body.preferredLocation,
      expectedSalary: req.body.expectedSalary,
      relocation: req.body.relocation,
      // media
      avatarData: req.body.avatarData,
      avatarMime: req.body.avatarMime,
      resumeData: req.body.resumeData,
      resumeName: req.body.resumeName,
    };

    Object.keys(updatable).forEach((k) => updatable[k] === undefined && delete updatable[k]);

    let updated = null;
    if (userType === 'student') {
      updated = await Student.findOneAndUpdate({ email }, { $set: updatable }, { new: true, runValidators: true });
    } else if (userType === 'recruiter') {
      updated = await Recruiter.findOneAndUpdate({ email }, { $set: updatable }, { new: true, runValidators: true });
    }
    if (!updated) return res.status(404).json({ message: 'User not found' });
    delete updated.password;
    res.json({ user: updated, message: 'Profile updated' });
  } catch (e) {
    console.error('Update profile error:', e);
    logError('update_profile', e);
    if (e.code === 11000 && e.keyPattern && e.keyPattern.username) {
      return res.status(409).json({ message: 'Username already taken' });
    }
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Application endpoints
app.post('/api/applications', async (req, res) => {
  try {
    const {
      applicantEmail,
      applicantName,
      applicantContact,
      applicationType,
      targetId,
      targetTitle,
      targetCompany,
      resumeData,
      resumeName
    } = req.body;

    // Validate required fields
    if (!applicantEmail || !applicantName || !applicantContact || !applicationType ||
      !targetId || !targetTitle || !targetCompany || !resumeData || !resumeName) {
      return res.status(400).json({ message: 'Missing required fields.' });
    }

    // Check if user already applied for this position
    const existingApplication = await Application.findOne({
      applicantEmail,
      targetId,
      applicationType
    });

    if (existingApplication) {
      return res.status(409).json({ message: 'You have already applied for this position.' });
    }

    // Create new application
    const application = USE_LOCAL_DB ? newApplication({
      applicantEmail,
      applicantName,
      applicantContact,
      applicationType,
      targetId,
      targetTitle,
      targetCompany,
      resumeData,
      resumeName
    }) : new Application({
      applicantEmail,
      applicantName,
      applicantContact,
      applicationType,
      targetId,
      targetTitle,
      targetCompany,
      resumeData,
      resumeName
    });

    await application.save();

    res.status(201).json({
      message: 'Application submitted successfully!',
      application: {
        id: application._id,
        status: application.status,
        appliedAt: application.appliedAt
      }
    });

  } catch (err) {
    console.error('Application submission error:', err);
    logError('post_application', err);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Contact message endpoint
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, subject, message, userType } = req.body;
    if (!name || !email || !subject || !message) {
      return res.status(400).json({ message: 'All fields are required.' });
    }
    const doc = await ContactMessage.create({ name, email, subject, message, userType: userType || 'student' });
    res.status(201).json({ message: 'Message received. We will get back to you soon.', id: doc._id });
  } catch (err) {
    console.error('Contact message error:', err);
    logError('contact', err);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Get applications for a user
app.get('/api/applications', async (req, res) => {
  try {
    const { email, applicationType } = req.query;

    if (!email) {
      return res.status(400).json({ message: 'Email is required.' });
    }

    const filter = { applicantEmail: email };
    if (applicationType) {
      filter.applicationType = applicationType;
    }

    let applications = await Application.find(filter);
    applications.sort((a, b) => new Date(b.appliedAt || b.createdAt || 0) - new Date(a.appliedAt || a.createdAt || 0));
    applications = applications.map((a) => {
      const c = { ...a };
      delete c.resumeData;
      return c;
    });

    res.json({ applications });

  } catch (err) {
    console.error('Get applications error:', err);
    logError('get_applications', err);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Get applications for recruiters (by target company)
app.get('/api/applications/company', async (req, res) => {
  try {
    const { company, applicationType } = req.query;

    if (!company) {
      return res.status(400).json({ message: 'Company is required.' });
    }

    const filter = { targetCompany: { $regex: company, $options: 'i' } };
    if (applicationType) {
      filter.applicationType = applicationType;
    }

    let applications = await Application.find(filter);
    applications.sort((a, b) => new Date(b.appliedAt || b.createdAt || 0) - new Date(a.appliedAt || a.createdAt || 0));
    applications = applications.map((a) => {
      const c = { ...a };
      delete c.resumeData;
      return c;
    });

    res.json({ applications });

  } catch (err) {
    console.error('Get company applications error:', err);
    logError('get_company_applications', err);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Update application status (for recruiters)
app.put('/api/applications/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, notes } = req.body;

    if (!status || !['pending', 'reviewed', 'shortlisted', 'rejected', 'accepted'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status.' });
    }

    const updateData = { status };
    if (status !== 'pending') {
      updateData.reviewedAt = new Date();
    }
    if (notes) {
      updateData.notes = notes;
    }

    let application = await Application.findByIdAndUpdate(
      id,
      updateData,
      { new: true }
    );
    if (application) {
      const c = { ...application };
      delete c.resumeData;
      application = c;
    }

    if (!application) {
      return res.status(404).json({ message: 'Application not found.' });
    }

    res.json({
      message: 'Application status updated successfully.',
      application
    });

  } catch (err) {
    console.error('Update application status error:', err);
    logError('update_application_status', err);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Resume download endpoint
app.get('/api/applications/:id/resume', async (req, res) => {
  try {
    const { id } = req.params;
    const application = await Application.findById(id);
    if (!application) {
      return res.status(404).json({ message: 'Application not found.' });
    }
    if (!application.resumeData || !application.resumeName) {
      return res.status(404).json({ message: 'Resume not found for this application.' });
    }
    const fileBuffer = Buffer.from(application.resumeData, 'base64');
    const fileName = application.resumeName;
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    return res.send(fileBuffer);
  } catch (err) {
    console.error('Get resume error:', err);
    logError('get_resume', err);
    res.status(500).json({ message: 'Internal server error.' });
  }
});

// Fallback JSON 404 for unknown /api routes (avoid HTML responses)
app.use('/api', (req, res) => {
  res.status(404).json({ message: 'Not found' });
});

// Serve static files from the React app (adjust path as needed)
app.use(express.static(path.join(__dirname, '../placement/dist')));

// Catch-all route to serve React's index.html for non-API routes
app.get(/^((?!\/api\/).)*$/, (req, res) => {
  res.sendFile(path.join(__dirname, '../placement/dist/index.html'));
});

app.listen(PORT, HOST, () => {
  console.log(`Server running at http://${HOST}:${PORT}`);
}); 